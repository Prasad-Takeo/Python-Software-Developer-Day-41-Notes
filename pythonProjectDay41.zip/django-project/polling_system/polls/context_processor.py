import datetime

def get_current_year_to_context(request):
    if request.user.is_authenticated:
        return {
            "logged_in_data_with_time":f"You're logged in as {request.user}, current datetime is {datetime.datetime.now()}"
        }
    return {
        "logged_in_data_with_time": ""
    }



"""
you're are logged in as Sugumar, current datetime is 03 June 2022 hh:mm:ss
"""
from django.urls import path

from . import views
from django.contrib.auth.decorators import login_required

urlpatterns = [
    #ex: /polls/
    path("",login_required(views.IndexView.as_view()),name="index"),
    #ex: /polls/5
    path("<int:pk>/", views.DetailView.as_view(), name="detail"),
    #ex: /polls/5/results
    path("<int:pk>/results/",views.ResultsView.as_view(),name="results"),
    #ex: /polls/5/vote
    path("<int:question_id>/vote/",views.vote,name="vote"),
    #ex: /polls/create_question
    path("create_question/",views.CreateQuestion.as_view(),name="create_question"),
    path("<int:pk>/update/",views.UpdateQuestion.as_view(),name="update_question"),
    path("<int:pk>/delete/",views.DeleteQuestion.as_view(),name="delete_question"),
    path("create_choice/",views.CreateChoice.as_view(),name="create_choice"),
    path("register/",views.register_request,name="register"),
    path("login/",views.login_request,name="login"),
    path("logout/",views.logout_request,name="logout"),
]

"""
create a Template and view the creating the question
"""
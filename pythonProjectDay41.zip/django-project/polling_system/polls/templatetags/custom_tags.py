from django import template
from polls.models import Question
register = template.Library()

import datetime

@register.simple_tag
def current_time(format_string):
    return datetime.datetime.now().strftime(format_string)

@register.filter(name='upper')
def upper(value):
    return value.lower()

@register.simple_tag
def polls_questions_count():
    return Question.objects.all().count()

@register.inclusion_tag('blog_list2.html')
def show_questions():
    obj = Question.objects.all()
    return {'objects':obj}